const express = require("express");
const router = express.Router();

const {
  register,
  login,
  getMyProfile,
  updateProfile,
} = require("../controllers/authController");

const authMiddleware = require("../middleware/authMiddleware");

router.post("/register", register);
router.post("/login", login);

router.get("/me", authMiddleware, getMyProfile);
router.put("/profile", authMiddleware, updateProfile);

module.exports = router;